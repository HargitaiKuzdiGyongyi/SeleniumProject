package hu.masterfield.browser;

public class TwoFactor {
}
