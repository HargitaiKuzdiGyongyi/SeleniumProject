package hu.masterfield.pages;

import org.openqa.selenium.WebDriver;

public class DepositPage extends BasePage{

    public DepositPage(WebDriver driver) {
        super(driver);
    }
}
