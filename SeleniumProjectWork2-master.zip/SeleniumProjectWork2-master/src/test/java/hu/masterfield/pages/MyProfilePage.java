package hu.masterfield.pages;

import org.openqa.selenium.WebDriver;

public class MyProfilePage extends BasePage{

    public MyProfilePage(WebDriver driver) {
        super(driver);
    }
}
