package hu.masterfield.pages;

import org.openqa.selenium.WebDriver;

public class TransactionsPage extends BasePage{

    public TransactionsPage(WebDriver driver) {
        super(driver);
    }
}
